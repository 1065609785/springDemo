1、apollo.tar.gz是在linux 解压后，执行./start.sh 服务就起来了（如果没有该文件，请下载链接：https://pan.baidu.com/s/1uSvuLt4GCdAQE0wvOTcgBA 密码：k6jr）
2、apollo-demo.zip是客户端项目
3、apollo.zip是apollo-demo依赖的jar包，放入maven仓库即可



ps：以上的端口设置为192.168.31.128  
eclipse：
-Denv=zhaoshouyun
-Ddev_meta=http://192.168.31.129:8080

相关文档请参考：https://github.com/ctripcorp/apollo/wiki